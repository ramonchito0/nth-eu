<?php
// inc/block-styles.php for nthdegreesearch

// add_action('init', function(){
//     if ( function_exists('register_block_style') ) {
//         register_block_style('core/button', array(
//             'name'  => 'large',
//             'label' => __('Large (Zodiak)', 'nthdegreesearch'),
//             'inline_style' => '.wp-block-button.is-style-large .wp-block-button__link{padding:16px 18px;font-size:18px;font-family:Zodiak,system-ui;font-weight:700;background:#D7CFC5;color:#1C1C1C;border-radius:8px;}'
//         ));
//     }
// });




