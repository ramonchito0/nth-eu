<?php
require_once get_template_directory() . '/inc/theme-setup.php';
require_once get_template_directory() . '/inc/enqueue-scripts.php';
require_once get_template_directory() . '/inc/acf-functions.php';
require_once get_template_directory() . '/inc/template-tags.php';
require_once get_template_directory() . '/inc/blocks.php';
require_once get_template_directory() . '/inc/fonts.php';
require_once get_template_directory() . '/inc/custom-functions.php';
require_once get_template_directory() . '/inc/property-map.php';
require_once get_template_directory() . '/inc/shortcodes.php';